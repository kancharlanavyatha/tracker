---
name: Ethereal Nymph Athletic
colors:
  surface: '#fbf9f7'
  surface-dim: '#dbdad8'
  surface-bright: '#fbf9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f1'
  surface-container: '#efedec'
  surface-container-high: '#eae8e6'
  surface-container-highest: '#e4e2e0'
  on-surface: '#1b1c1b'
  on-surface-variant: '#534346'
  inverse-surface: '#30302f'
  inverse-on-surface: '#f2f0ee'
  outline: '#867276'
  outline-variant: '#d8c1c5'
  surface-tint: '#94455b'
  primary: '#94455b'
  on-primary: '#ffffff'
  primary-container: '#e0839b'
  on-primary-container: '#611d33'
  inverse-primary: '#ffb1c3'
  secondary: '#3a6759'
  on-secondary: '#ffffff'
  secondary-container: '#bceddc'
  on-secondary-container: '#406d5f'
  tertiary: '#67558c'
  on-tertiary: '#ffffff'
  tertiary-container: '#aa95d1'
  on-tertiary-container: '#3e2c61'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd9e0'
  primary-fixed-dim: '#ffb1c3'
  on-primary-fixed: '#3e0119'
  on-primary-fixed-variant: '#772e44'
  secondary-fixed: '#bceddc'
  secondary-fixed-dim: '#a1d0c0'
  on-secondary-fixed: '#002019'
  on-secondary-fixed-variant: '#214f42'
  tertiary-fixed: '#ebddff'
  tertiary-fixed-dim: '#d2bcfb'
  on-tertiary-fixed: '#220f44'
  on-tertiary-fixed-variant: '#4f3d73'
  background: '#fbf9f7'
  on-background: '#1b1c1b'
  surface-variant: '#e4e2e0'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 34px
    fontWeight: '600'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1.25rem
  margin-md: 2rem
  margin-lg: 3.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses an ethereal, luminous sanctuary tailored for female athletic menstrual performance, somatic awareness, and hormonal rhythm tracking. It rejects cold, clinical medical interfaces and aggressive high-friction gym aesthetics. Instead, it frames biological cycles, recovery metrics, and athletic output as an interconnected, natural tide.

The aesthetic fuses **delicate modern minimalism** with **luminous glassmorphism** and soft organic botanics:
- **Atmosphere:** Translucent, airy, weightless, and glowing with inner vitality.
- **Tone:** Reverent, uplifting, deeply encouraging, and biologically precise without ever feeling sterile.
- **Visual Signature:** Frosted glass panels layered over gentle radial aurora glows (rose quartz, sage mist, sunlit champagne), whispering borders, and refined modern typography anchored by quiet editorial accents.

## Colors

The palette derives from minerals, botanical flora, and shifting ambient light:

- **Primary (`#E0839B` - Rose Quartz Bloom):** The vital energetic pulse. Used for active cycle phase highlights, peak energy indicators, primary interactive buttons, and biometric progress rings.
- **Secondary (`#6C9A8B` - Luminous Moss & Sage):** Restorative balance. Used for recovery scores, follicular phase states, active recovery metrics, and botanical accent seals.
- **Tertiary (`#B19CD9` - Amethyst Lavender):** Intuition and rest. Guides luteal transitions, sleep readiness indicators, mindful hydration cues, and reflective states.
- **Accent Champagne (`#F0D7A7` - Sunlit Champagne):** Ovulation peaks, PR badges, glowing focal points, and golden energy surges.
- **Neutral Canvas (`#FBF9F7` - Iridescent Pearl):** The breathing canvas, providing warmth and avoiding harsh electronic starkness.
- **Subtle Surface (`#F3EFEA` - Dew Soft Linen):** Base backdrop for card backplanes and resting containers.
- **Text & Contrast (`#2D2627` - Deep Earth Bramble):** Deep charcoal with a warm plum-brown undertone ensuring crisp legibility while remaining soft against pastel luminescence.

## Typography

Typography balances athletic metric rigor with botanical grace:
- **Headlines (`Plus Jakarta Sans`):** Soft geometric curves with an open aperture, providing warmth, modern optimism, and a friendly, human cadence to milestone indicators and section greetings.
- **Body & Data (`Geist`):** Delivers clean, technical precision for athletic workloads, basal body temperatures, resting heart rates, and cycle calculations without sacrificing spacious elegance.
- **Editorial Emphasis:** Use `headline-md` italicised sparingly for personalized physiological insights, phase mantras, or daily somatic guidance.

## Layout & Spacing

The layout is airy, intentional, and uncluttered, relying on gentle rhythm and deep negative space to lower cognitive load and sympathetic nervous system activation:

- **Grid Architecture:** 
  - Mobile: 4 columns with `1.25rem` margins and `1rem` gutters.
  - Tablet: 8 columns with `2rem` margins and `1.5rem` gutters.
  - Desktop: 12 columns constrained to a max-width of `1280px` with `3.5rem` margins and `2rem` gutters.
- **Atmospheric Padding:** Screen sections and card clusters maintain wide vertical gaps (`space-xl`) to feel light and float effortlessly. Small inline elements and metric chips employ tight internal nests (`space-xs` to `space-sm`).

## Elevation & Depth

Visual hierarchy uses ethereal luminosity, spectral diffusion, and physical glass refraction rather than opaque shadow stacking:

- **Ethereal Ambient Diffusion:** Shadows never use pure black or grey. They utilize low-opacity, wide-spread radial tints: `0 12px 32px -4px rgba(224, 131, 155, 0.12)` or `0 16px 40px -8px rgba(108, 154, 139, 0.14)`.
- **Frosted Glass (Surface Containers):** Background fill of `rgba(255, 255, 255, 0.65)` to `rgba(255, 255, 255, 0.85)` with `backdrop-filter: blur(18px) saturate(140%)`.
- **Whispering Borders:** 1px hairline perimeter borders layered with gradient masks: `linear-gradient(135deg, rgba(255, 255, 255, 0.8), rgba(224, 131, 155, 0.25))`.
- **Glow Halos:** Interactive states or peak biological metrics (e.g., peak ovulation, optimal recovery window) emit a soft, pulsating radial gradient behind the surface container.

## Shapes

The form language is organic, continuous, and soft to evoke botanical petals, smooth river stones, and natural water droplets:
- **Card Containers:** Deep, pillowy radii (`rounded-xl` at `3rem` or `rounded-lg` at `2rem`) eliminating harsh angles.
- **Interactive Triggers & Chips:** Full pill radii (`border-radius: 9999px`) to create tactile, touch-friendly touchpoints.
- **Decorative Elements:** Asymmetrical, gently curved organic masks for progress tracks, recovery bars, and celestial constellation trackers.

## Components

### Buttons
- **Primary Action (Luminous Pulse):** Pill-shaped with a subtle gradient background (`#E0839B` transitioning to `#F0D7A7`), crisp white text, and an inner white top-edge reflection (`inset 0 1px 1px rgba(255, 255, 255, 0.6)`). Accompanied by a soft Rose Quartz ambient halo.
- **Secondary (Glass Petal):** Translucent white glass background (`rgba(255, 255, 255, 0.7)`), 1px border tinted in Sage or Rose Quartz, with Deep Earth Bramble typography.

### Chips & Luminous Micro-Badges
- Miniature pills (`border-radius: 9999px`) combining a celestial symbol (✦, ✧, ☾) or botanical leaf icon with micro uppercase type (`label-caps`).
- Tinted according to physiological phase:
  - *Menstrual:* Rose mist background (`rgba(224, 131, 155, 0.15)`), Rose text.
  - *Follicular / Strength Surge:* Moss mist background (`rgba(108, 154, 139, 0.15)`), Moss text.
  - *Ovulatory / Peak Power:* Champagne sunlit tint (`rgba(240, 215, 167, 0.35)`), Warm Gold-Amber text.
  - *Luteal / Deep Recovery:* Amethyst tint (`rgba(177, 156, 217, 0.18)`), Lavender text.

### Cards
- Constructed with frosted glass panels and soft pearl backplates.
- Inner elements breathe freely with `1.5rem` to `2rem` internal padding.
- Hairline gradient borders simulate light catching the bevel of an opal or pearl.

### Form Inputs & Checkboxes
- **Input Fields:** Recessed pearl-pill troughs with a subtle inset tint, transitioning smoothly on focus to a glowing Rose Quartz hairline border with an expanded blur ring.
- **Checkboxes & Radios:** Smooth, pebble-shaped circular toggles with seamless spring animations. Checked states illuminate with glowing secondary or primary tones.

### Domain-Specific Components
- **Cycle Horizon Wheel:** An iridescent, circular dial tracking the 28–35 day rhythm, employing soft water-droplet markers for phase transitions, training intensity recommendations, and temperature shifts.
- **Somatic Athletic Readiness Meter:** A glowing, frosted capsule representing readiness for high-strain training (plyometrics, heavy compound lifts) versus restorative phases (mobility, zone 2 work), framed by delicate botanical flourishes.